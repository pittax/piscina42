#include "rush01.c"

int main()
{
rush(10, 5);
return (0);
}
