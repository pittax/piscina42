#include <stdio.h>
#include <unistd.h>
#include "ft_putchar.c"

void  rush(int x, int y)
{
int i;
int j;
i = 0;
j = 0;

while  (i <= x)
{
while(j <= y)
{

	if(i==0 && j==0){ft_putchar('/');}		
	if(i==0 && j>0){ft_putchar('*');}
	if(i==0 && j==y){ft_putchar('\\');}

//	if(){ft_putchar('*');}
	if((i<x && i>0) && (j>0 && j<y)){ft_putchar(' ');}
	if((i<x && i>0) && j==y){ft_putchar('*');}

	if(i==x && j==0){ft_putchar('\\');}
	if(i==x && j>0){ft_putchar('*');}
	if(i==x && j==y){ft_putchar('/');}
j++;

}
		j = 0;
		write(1,"\n",1);
		i++;
}



}
